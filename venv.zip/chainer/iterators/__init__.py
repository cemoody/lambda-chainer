from chainer.iterators import multiprocess_iterator
from chainer.iterators import serial_iterator


MultiprocessIterator = multiprocess_iterator.MultiprocessIterator
SerialIterator = serial_iterator.SerialIterator
