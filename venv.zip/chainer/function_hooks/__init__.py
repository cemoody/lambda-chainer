from chainer.function_hooks import debug_print
from chainer.function_hooks import timer


PrintHook = debug_print.PrintHook
TimerHook = timer.TimerHook
